﻿#include <cassert>

// 7 page

// static_assert : 컴파일시간 표현식의 유효성을 조사, 
//				   false 인 경우, 컴파일을 중지하고, 메세지 출력

static_assert(sizeof(void*) == 8, "error, this code can use only 64 bit!");

int main()
{

}
