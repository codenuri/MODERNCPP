﻿// 3_noexcept - 14 page
#include <iostream>
#include <exception>

// noexcept
// #1. 함수가 예외가 있는지 없는지 조사
// #2. 함수가 예외가 없음을 알리기 위해 사용

void foo() 
{
}
void goo()
{
}

int main()
{
}




