﻿// 9_enum - 32 page

enum COLOR { red = 0, green = 1, blue = 2};

int main()
{
	int n1 = COLOR::red;
	int n2 = red;

	int red = 10;
	int n3 = red; // ??


}





