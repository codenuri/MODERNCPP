﻿// auto - 68 page 배울때 자세히
// 지금은 소개만. 

int main()
{
	int n1 = 0;

	auto a1 = 3;
	auto a2 = 3.4;
}


// 빌드 하는 법
// Ctrl + F5
