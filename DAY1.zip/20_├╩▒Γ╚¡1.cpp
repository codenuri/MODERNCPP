﻿#include <iostream>

class Point
{
	int x = 0;  // C++11 부터 멤버데이타(필드)를 직접 초기화 가능 
	int y = 0;
public:
	Point() {}
	Point(int y)        : y(y) {}
	Point(int x, int y) : x(x), y(y) {}
};

int main()
{
	Point pt(1, 1);
}
