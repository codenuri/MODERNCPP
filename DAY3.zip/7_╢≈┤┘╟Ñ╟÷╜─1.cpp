﻿// 5_람다표현식1
#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>

int main()
{
	std::vector<int> v = { 1,3,5,7,9,2,4,6,8,10 };
	
	// #1. 비교정책을 전달하지 않은 경우
	std::sort(v.begin(), v.end()); 

	// #2. 비교정책을 일반 함수로 전달하는 경우
	std::sort(v.begin(), v.end(), cmp1);


	// #3. 비교 정책으로 함수 객체를 사용하는 경우

	std::sort(v.begin(), v.end(), ?);


	// #4. 비교 정책으로 람다 표현식을 사용하는 경우
}





