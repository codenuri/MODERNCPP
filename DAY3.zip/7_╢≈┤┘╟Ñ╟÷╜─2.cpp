﻿// 5_람다표현식1
#include <iostream>
#include <algorithm>
#include <functional>

int main()
{
	std::vector<int> v = { 1,3,5,7,9,2,4,6,8,10 };

	// 람다 표현식의 원리
	std::sort(v.begin(), v.end(), [](int a, int b) { return a < b; });

}





