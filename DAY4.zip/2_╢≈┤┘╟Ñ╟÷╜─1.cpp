﻿#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>

bool cmp(int a, int b) { return a < b; }

int main()
{
	std::vector<int> v = { 1,3,5,7,9,2,4,6,8,10 };
	
	// #1. 비교정책을 전달하지 않은 경우
	std::sort(v.begin(), v.end()); 

	// #2. 비교정책으로 일반 함수를 사용
	std::sort(v.begin(), v.end(), cmp);

	// #3. 비교정책으로 함수객체를 사용
	std::sort(v.begin(), v.end(), ?);
}





