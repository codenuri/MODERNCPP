﻿#include <iostream>

// 함수객체와 const member function

struct Plus
{
	int operator()(int a, int b)
	{
		return a + b;
	}
};

// 함수 객체를 함수 인자로 받는 경우
template<typename T> void foo(T f)
{
	int ret = f(1, 2);
}

int main()
{
	Plus p;

	foo(p);
}
