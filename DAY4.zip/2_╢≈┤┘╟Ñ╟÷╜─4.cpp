﻿#include <iostream>

// auto 와 람다 표현식
int main()
{
	// 람다 표현식 활용
	// #1. std::sort(), std::find() 등의 알고리즘에 인자로 전달
	// #2. auto 변수에 담아서 함수 처럼 사용

	[](int a, int b) { return a + b; };
}

