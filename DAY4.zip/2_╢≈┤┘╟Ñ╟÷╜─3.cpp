﻿#include <iostream>
#include <algorithm>
#include <vector>

bool foo(int n) { return n % 3 == 0; }

int main()
{
	std::vector<int> v = { 1,2,6,5,4,3 };

	int k = 3;

	// 주어진 구간에서 k 의 배수를 찾고 싶다.
	auto p = std::find_if(v.begin(), v.end(), foo );
}

