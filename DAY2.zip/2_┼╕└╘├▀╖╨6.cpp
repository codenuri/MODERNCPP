﻿// decltype 타입 추론 - 71page
int main()
{
	int n = 10;
	int& r = n;
	const int c = 10;
	int* p = &n;

	// decltype(expression)
	// 규칙 #1. expression 이 심볼의 이름일때
	decltype(n) d1; // 
	decltype(r) d2; // 
	decltype(c) d3; // 
	decltype(p) d4; // 
}
