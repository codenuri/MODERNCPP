﻿#include <iostream>

class Point
{
	int x;
	int y;
public:
	Point()				: x{ 0 }, y{ 0 } {}
	Point(int a, int b) : x{ a }, y{ b } {}
};

void foo(Point pt)
{
}

int main()
{
	Point p1{ 1,2 };
	Point p2 = { 1,2 };

	foo(p1);
}