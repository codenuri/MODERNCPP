﻿#include <iostream>

// 가변인자 함수 템플릿

template<typename T> 
void goo(T arg)
{
}

template<typename ... Types> 
void foo(Types ... args)
{
}

int main()
{
	foo(1);
	foo(1, 3.4);
	foo(1, 3.4, 'A');
}
