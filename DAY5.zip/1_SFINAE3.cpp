#include <iostream>
#include <type_traits>

template<typename T>
void foo(T n)
{
	typename T::type n;	// SFINAE �� ����ɱ�� ?
}

int main()
{
	foo(0);
}